<?php
	session_start();
	require("../libraries/config.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PHPANDMYSQL.NET</title>
</head>

<body>
<?php
	if(isset($_POST['ok'])){
		$name = "";
		$pass = "";
		if($_POST['user_name'] == ""){
			echo "Please enter your name!";
			die();
		}else{
			$name = $_POST['user_name'];
		}
		if($_POST['user_pass'] == ""){
			echo "Please enter your pass!";
			die();
		}else{
			$pass = md5($_POST['user_pass']);
		}
		$sql = "select * from tbl_teachers where teacher_name = '".$name."' and teacher_pass = '".$pass."'";
		$result = mysql_query($sql);
		$numrow = mysql_num_rows($result);
		if($numrow > 0){ // Đúng username và password
			$data = mysql_fetch_assoc($result);
			$_SESSION['ses_id'] = $data['teacher_id'];
			$_SESSION['ses_name'] = $data['teacher_name'];
			header("location:index.php");
			exit();
		}else{
			echo "Wrong username or password!";
			die();
		}
	}
?>
<form action="login.php" method="post">
	Tên đăng nhập : <input type="text" name="user_name" size="20" /><br />
    Mật khẩu : <input type="password" name="user_pass" size="20" /><br />
    <input type="submit" name="ok" value="Đăng nhập" />
</form>
</body>
</html>
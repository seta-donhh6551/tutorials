-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 28, 2013 at 04:38 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `students`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_classes`
--

CREATE TABLE IF NOT EXISTS `tbl_classes` (
  `class_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class_name` varchar(100) NOT NULL,
  `faculty_id` int(10) NOT NULL,
  `teacher_id` int(10) NOT NULL,
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_faculties`
--

CREATE TABLE IF NOT EXISTS `tbl_faculties` (
  `faculty_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `faculty_name` varchar(100) NOT NULL,
  `faculty_status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`faculty_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_scores`
--

CREATE TABLE IF NOT EXISTS `tbl_scores` (
  `score_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `score_cc` int(10) NOT NULL,
  `score_tx` int(10) NOT NULL,
  `score_ghp` int(10) NOT NULL,
  `score_kthp` int(10) NOT NULL,
  `subject_id` int(10) NOT NULL,
  `student_id` int(10) NOT NULL,
  PRIMARY KEY (`score_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_students`
--

CREATE TABLE IF NOT EXISTS `tbl_students` (
  `student_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_name` varchar(100) NOT NULL,
  `student_pass` char(50) NOT NULL,
  `student_fullname` varchar(150) NOT NULL,
  `student_phone` int(15) NOT NULL,
  `student_email` varchar(100) NOT NULL,
  `student_add` varchar(150) NOT NULL,
  `student_gender` int(1) NOT NULL,
  `student_status` int(1) NOT NULL DEFAULT '1',
  `class_id` int(10) NOT NULL,
  `faculty_id` int(10) NOT NULL,
  `year_id` int(10) NOT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subjects`
--

CREATE TABLE IF NOT EXISTS `tbl_subjects` (
  `subject_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject_name` varchar(150) NOT NULL,
  `subject_status` int(1) NOT NULL DEFAULT '1',
  `faculy_id` int(10) NOT NULL,
  PRIMARY KEY (`subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_teachers`
--

CREATE TABLE IF NOT EXISTS `tbl_teachers` (
  `teacher_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `teacher_name` varchar(100) NOT NULL,
  `teacher_pass` char(50) NOT NULL,
  `teacher_fullname` varchar(150) NOT NULL,
  `teacher_phone` int(15) NOT NULL,
  `teacher_email` varchar(100) NOT NULL,
  `teacher_add` varchar(150) NOT NULL,
  `teacher_gender` int(1) NOT NULL,
  `teacher_status` int(1) NOT NULL DEFAULT '1',
  `faculty_id` int(10) NOT NULL,
  PRIMARY KEY (`teacher_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_teachers`
--

INSERT INTO `tbl_teachers` (`teacher_id`, `teacher_name`, `teacher_pass`, `teacher_fullname`, `teacher_phone`, `teacher_email`, `teacher_add`, `teacher_gender`, `teacher_status`, `faculty_id`) VALUES
(1, 'haanhdon', '827ccb0eea8a706c4c34a16891f84e7b', 'Hà Hữu Đôn', 974136509, 'haanhdon@gmail.com', 'Cầu Giấy - Hà Nội', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_years`
--

CREATE TABLE IF NOT EXISTS `tbl_years` (
  `year_id` int(10) unsigned NOT NULL,
  `year_title` varchar(200) NOT NULL,
  PRIMARY KEY (`year_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

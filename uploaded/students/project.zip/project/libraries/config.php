<?php
	$host = "localhost";
	$user = "root";
	$pass = "";
	$db = mysql_connect($host,$user,$pass) or die("Can't connect to database!");
	mysql_select_db("students",$db) or die("Can't select database!");
	mysql_query("SET NAMES utf8");
?>
<?php
	if($_POST['num_a'] == NULL){
		echo "Vui long nhap A";
		die();
	}else{
		$a = $_POST['num_a'];
	}
	if($_POST['num_b'] == NULL){
		echo "Vui long nhap B";
		die();
	}else{
		$b = $_POST['num_b'];
	}
	$x = (-$b/$a);
	echo "X = ".$x;
?>